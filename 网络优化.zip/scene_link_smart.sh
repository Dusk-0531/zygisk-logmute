. /data/adb/modules/realme_gt5_modem_full_channel_opt/qos_priority.conf
. /data/adb/modules/realme_gt5_modem_full_channel_opt/router_mgmt_frame.conf
. /data/adb/modules/realme_gt5_modem_full_channel_opt/channel_time_slice.conf
. /data/adb/modules/realme_gt5_modem_full_channel_opt/get_current_carrier.sh
detect_game_pro() {
    local game_pkgs=(
        "com.tencent.tmgp.pubgmhd" "com.tencent.tmgp.sgame" "com.tencent.kgame"
        "com.riotgames.league.wildrift" "com.tencent.mobilelegends"
        "com.netease.na5" "com.netease.eastwood" "com